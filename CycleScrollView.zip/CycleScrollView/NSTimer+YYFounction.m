//
//  SelcetViewController.m
//  EasyToLearn
//
//  Created by wql on 16/10/12.
//  Copyright © 2016年 wql. All rights reserved.
//


#import "NSTimer+YYFounction.h"

@implementation NSTimer (YYFounction)

-(void)pauseTimer
{
    if (![self isValid]) {
        return ;
    }
    [self setFireDate:[NSDate distantFuture]];
}


-(void)resumeTimer
{
    if (![self isValid]) {
        return ;
    }
    [self setFireDate:[NSDate date]];
}

- (void)resumeTimerAfterTimeInterval:(NSTimeInterval)interval
{
    if (![self isValid]) {
        return ;
    }
    [self setFireDate:[NSDate dateWithTimeIntervalSinceNow:interval]];
}


@end
