//
//  SelcetViewController.m
//  EasyToLearn
//
//  Created by wql on 16/10/12.
//  Copyright © 2016年 wql. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface NSTimer (YYFounction)

- (void)pauseTimer;
- (void)resumeTimer;
- (void)resumeTimerAfterTimeInterval:(NSTimeInterval)interval;


@end
